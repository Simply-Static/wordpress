<?php
/**
 * Title: Blog Page
 * Slug: ollie/blog-page
 * Description: A full page design for a blog page
 * Categories: ollie/pages
 * Keywords: page, layout, design, template, blog, posts, query
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/post-loop-grid"} /-->
