<?php
/**
 * Title: Download Page
 * Slug: ollie/page-download
 * Description: A full page design for a Download page
 * Categories: ollie/pages
 * Keywords: page, layout, design, template, download
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/text-and-details-card"} /-->

<!-- wp:pattern {"slug":"ollie/faq"} /-->

<!-- wp:pattern {"slug":"ollie/testimonials-with-social-links"} /-->

<!-- wp:pattern {"slug":"ollie/image-and-numbered-features"} /-->

<!-- wp:pattern {"slug":"ollie/text-call-to-action-buttons"} /-->
