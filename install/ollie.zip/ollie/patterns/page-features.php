<?php
/**
 * Title: Features Page
 * Slug: ollie/page-features
 * Description: A full page design for a Features page
 * Categories: ollie/pages, ollie/features
 * Keywords: page, layout, design, template, features
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/card-text-and-call-to-action"} /-->

<!-- wp:pattern {"slug":"ollie/feature-boxes-with-button"} /-->

<!-- wp:pattern {"slug":"ollie/features-with-emojis"} /-->

<!-- wp:pattern {"slug":"ollie/testimonial-highlight"} /-->
