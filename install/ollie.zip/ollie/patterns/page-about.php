<?php
/**
 * Title: About Page
 * Slug: ollie/page-about
 * Description: A full page design for an About page
 * Categories: ollie/pages
 * Keywords: page, layout, design, template
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/contact-details"} /-->

<!-- wp:pattern {"slug":"ollie/team-members"} /-->

<!-- wp:pattern {"slug":"ollie/numbers-stacked"} /-->

<!-- wp:pattern {"slug":"ollie/job-openings"} /-->
