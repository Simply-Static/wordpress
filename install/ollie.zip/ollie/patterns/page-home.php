<?php
/**
 * Title: Homepage
 * Slug: ollie/page-home
 * Description: A full page design for a Homepage
 * Categories: ollie/pages
 * Keywords: page, layout, design, template, home
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/hero-text-image-and-logos"} /-->

<!-- wp:pattern {"slug":"ollie/large-text-and-text-boxes"} /-->

<!-- wp:pattern {"slug":"ollie/text-and-image-columns-with-icons"} /-->

<!-- wp:pattern {"slug":"ollie/numbers"} /-->

<!-- wp:pattern {"slug":"ollie/testimonials-and-logos"} /-->

<!-- wp:pattern {"slug":"ollie/text-and-image-columns-with-testimonial"} /-->

<!-- wp:pattern {"slug":"ollie/pricing-table"} /-->

<!-- wp:pattern {"slug":"ollie/blog-post-columns"} /-->

<!-- wp:pattern {"slug":"ollie/text-call-to-action"} /-->
