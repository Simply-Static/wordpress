<?php
/**
 * Title: Pricing Page
 * Slug: ollie/page-pricing
 * Description: A full page design for a Pricing page
 * Categories: ollie/pages, ollie/pricing
 * Keywords: page, layout, design, template, pricing
 * Viewport Width: 1500
 * Block Types:
 * Post Types:
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"ollie/pricing-table-with-testimonials"} /-->

<!-- wp:pattern {"slug":"ollie/faq"} /-->

<!-- wp:pattern {"slug":"ollie/numbers"} /-->
