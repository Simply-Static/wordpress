<?php

namespace Simply_Static_Studio\Queries;

class Model extends Query {}