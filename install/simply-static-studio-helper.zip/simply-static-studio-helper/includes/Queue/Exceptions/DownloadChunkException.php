<?php

namespace Simply_Static_Studio\Queue\Exceptions;

class DownloadChunkException extends \Exception {}