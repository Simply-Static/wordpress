<?php

namespace Simply_Static_Studio\Queue\Exceptions;

class DownloadChunkContinueException extends \Exception {}