<?php

namespace Simply_Static_Studio\Queue\Exceptions;

class SkippableException extends \Exception {}